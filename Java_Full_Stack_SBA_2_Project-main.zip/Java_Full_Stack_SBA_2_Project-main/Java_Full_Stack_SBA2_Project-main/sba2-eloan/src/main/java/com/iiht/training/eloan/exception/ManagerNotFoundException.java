package com.iiht.training.eloan.exception;

public class ManagerNotFoundException extends RuntimeException{

	public ManagerNotFoundException(String message) {
		super(message);
	}
}
