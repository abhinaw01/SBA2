package com.wellsfargo.eloan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sba2ELoanAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
